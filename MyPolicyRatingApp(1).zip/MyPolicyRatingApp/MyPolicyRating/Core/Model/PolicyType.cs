﻿using System;

namespace MyPolicyRating
{
    public enum PolicyType
    {
        Life = 0,
        Land = 1,
        Auto = 2,
        Flood = 3
    }
}
