﻿namespace MyPolicyRating
{
    public interface IPolicySource
    {
        string GetPolicyFromSource();
    }
}
