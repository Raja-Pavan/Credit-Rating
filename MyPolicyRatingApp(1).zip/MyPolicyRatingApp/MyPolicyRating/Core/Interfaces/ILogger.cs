﻿namespace MyPolicyRating
{
    public interface ILogger
    {
        void Log(string message);
    }
}
