﻿namespace MyPolicyRating
{
    public class NullLogger : ILogger
    {
        public void Log(string message)
        {
        }
    }
}
